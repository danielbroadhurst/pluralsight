exports.secrets = {
    SecretId: '--------------',
    SecretKey : '---------------------',
    EmailUser: '------------------',
    EmailPassword: '-----------------'
}