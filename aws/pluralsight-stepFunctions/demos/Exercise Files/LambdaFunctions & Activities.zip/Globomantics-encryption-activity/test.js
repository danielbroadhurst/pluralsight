var handler = require("./index")

handler.StartActivity()